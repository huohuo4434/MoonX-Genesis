@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [错误] 电脑没有检测到 Node.js 18 或以上版本。
  echo 请先按 README-先看我.txt 的说明安装 Node.js，再双击本文件。
  pause
  exit /b 1
)
node moox-readonly-monitor.mjs
pause
