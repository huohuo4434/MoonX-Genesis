import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const configPath = path.join(root, "MOOX配置.txt");
if (!fs.existsSync(configPath)) throw new Error("找不到 MOOX配置.txt");
const config = Object.fromEntries(fs.readFileSync(configPath, "utf8").split(/\r?\n/).map((line) => line.trim()).filter((line) => line && line.includes("=")).map((line) => { const index = line.indexOf("="); return [line.slice(0, index).trim(), line.slice(index + 1).trim()]; }));
const base = (config.MOOX_BASE_URL || "https://mooxintel.com").replace(/\/$/, "");
const token = config.MOOX_SIGNAL_TOKEN || "";
if (!token || token.includes("粘贴")) throw new Error("请先把网页生成的只读Token粘贴到 MOOX配置.txt");
const symbols = (config.MOOX_SYMBOLS || "BTC,ETH,SOL,HYPE").split(",").map((v) => v.trim().toUpperCase()).filter(Boolean);
const refreshSeconds = Math.max(30, Math.min(600, Number(config["刷新秒数"] || 60)));

async function load(symbol) {
  const response = await fetch(`${base}/api/v1/member/trading/plans/current?symbol=${encodeURIComponent(symbol)}`, { headers: { Authorization: `Bearer ${token}`, Accept: "application/json" } });
  const body = await response.json().catch(() => ({}));
  return response.ok ? { symbol, ok: true, plan: body } : { symbol, ok: false, error: body.error || `HTTP ${response.status}` };
}

async function run() {
  const rows = await Promise.all(symbols.map(load));
  const snapshot = { generatedAt: new Date().toISOString(), mode: "READ_ONLY", rows };
  fs.writeFileSync(path.join(root, "MOOX_READONLY_STATUS.json"), JSON.stringify(snapshot, null, 2), "utf8");
  console.clear();
  console.log("MOOX 会员只读监控（不下单）");
  console.log("更新时间:", new Date().toLocaleString("zh-CN"));
  console.log("----------------------------------------");
  for (const row of rows) {
    if (!row.ok) { console.log(`${row.symbol}: ${row.error}`); continue; }
    const plan = row.plan || {};
    console.log(`${row.symbol}: 方向=${plan.authority?.direction ?? "—"}  状态=${plan.state ?? "—"}  缠论=${plan.chan?.stageLabel ?? "—"}`);
    console.log(`  现价=${plan.execution?.currentPrice ?? "—"}  确认=${plan.execution?.confirmationAboveOrBelow ?? "—"}  失效=${plan.execution?.stopLoss ?? "—"}`);
  }
  console.log("----------------------------------------");
  console.log(`每 ${refreshSeconds} 秒刷新。关闭窗口即可停止。`);
}

await run();
setInterval(() => void run().catch((error) => console.error("刷新失败:", error.message)), refreshSeconds * 1000);
