MOOX会员只读监控 - 小白版
==========================

这个工具只读取MOOX已经发布的研究计划，不连接Bitget，不下单，不需要Bitget API密钥。

第一次只做3步：
1. 在MOOX会员AI页面点击“创建只读Token”，复制Token。
2. 用记事本打开“MOOX配置.txt”，把Token粘贴到 MOOX_SIGNAL_TOKEN= 后面并保存。
3. 双击“1-启动只读监控.cmd”。

运行后：
- 窗口每分钟刷新一次BTC/ETH/SOL/HYPE研究计划。
- 最新结果保存到同目录 MOOX_READONLY_STATUS.json。
- 关闭窗口即可停止，不会留下后台交易程序。

需要更多说明请看网站下载的《MOOX会员只读监控详细说明.md》。
