#!/usr/bin/env node
const confirm = String(process.env.MOOX_LIVE_TRADING_CONFIRM || "");
if (confirm !== "I_UNDERSTAND_LIVE_ORDERS") {
  console.error("Live trading is locked. Set MOOX_LIVE_TRADING_CONFIRM=I_UNDERSTAND_LIVE_ORDERS after reviewing the risk settings.");
  process.exit(2);
}
if (!process.env.BITGET_API_KEY || !process.env.BITGET_API_SECRET || !process.env.BITGET_API_PASSPHRASE) {
  console.error("Bitget API credentials are missing. Use read+trade permissions only; never enable withdrawal or transfer.");
  process.exit(2);
}
process.env.MOOX_AGENT_MODE = "LIVE";
process.env.MOOX_TRADING_MODE = "LIVE";
await import("./moox-bitget-local-agent.mjs");
