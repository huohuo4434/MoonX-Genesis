# MOOX Bitget Live Agent V7.20.3.1

This package is LIVE-ONLY. It does not upload Bitget secrets to the MOOX website.

1. Create a Bitget API key with READ and TRADE only.
2. Do not enable WITHDRAW or TRANSFER.
3. Bind the key to the fixed public IP of this computer/VPS.
4. Copy the env example and fill it locally.
5. Set `MOOX_LIVE_TRADING_CONFIRM=I_UNDERSTAND_LIVE_ORDERS` only after checking sizing, leverage, stop-loss and maximum-loss limits.
6. The website starts in MANAGE_ONLY. A local confirmation does not bypass the server custody gate.

Short, medium and long horizons use independent virtual ledgers. Exchange orders remain a single real net position per symbol.

---

