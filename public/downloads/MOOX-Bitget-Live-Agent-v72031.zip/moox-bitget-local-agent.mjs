throw new Error("Existing MOOX local agent was not collected; install blocked until supplied.");
